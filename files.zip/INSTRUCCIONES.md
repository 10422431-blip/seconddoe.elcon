# 🚀 CÓMO PUBLICAR SECONDDOE INTERNACIONALMENTE
## Sin saber programar — paso a paso

---

## PASO 1: SUBIR A GITHUB (5 minutos)

1. Ve a **github.com** e inicia sesión
2. Clic en el botón verde **"New"** (esquina superior izquierda)
3. Nombre del repositorio: `seconddoe`
4. Selecciona **"Public"**
5. Clic en **"Create repository"**
6. En la página que aparece, clic en **"uploading an existing file"**
7. **Arrastra TODOS estos archivos** a la ventana:
   - `vercel.json`
   - `api/chat.js` (primero crea una carpeta llamada `api`)
   - `public/index.html`
   - `public/manifest.json`
   - `public/sw.js`
   - `public/icon-192.png`
   - `public/icon-512.png`
8. Clic en **"Commit changes"** (botón verde abajo)

---

## PASO 2: PUBLICAR EN VERCEL (3 minutos)

1. Ve a **vercel.com** y clic en **"Sign up"**
2. Elige **"Continue with GitHub"** — se conecta automáticamente
3. Clic en **"Add New Project"**
4. Busca tu repositorio `seconddoe` y clic en **"Import"**
5. Antes de desplegar, agrega la API Key:
   - Clic en **"Environment Variables"**
   - Name: `ANTHROPIC_API_KEY`
   - Value: pega tu key `sk-ant-...`
   - Clic **"Add"**
6. Clic en **"Deploy"**
7. ¡Listo! Vercel te da una URL como `seconddoe.vercel.app`

⚠️ **La API Key de Anthropic:**
- Consíguela gratis en console.anthropic.com
- Anthropic te da $5 de crédito gratis al registrarte
- Eso son miles de conversaciones

---

## PASO 3: APP MÓVIL SIN PLAY STORE (PWA)

La app ya está configurada como PWA (Progressive Web App).
Cualquier persona puede instalarla en su celular así:

**En Android (Chrome):**
1. Abre la URL de tu app en Chrome
2. Toca los 3 puntos (⋮) arriba a la derecha
3. Toca **"Agregar a pantalla de inicio"**
4. ¡Aparece como app nativa en el celular!

**En iPhone (Safari):**
1. Abre la URL en Safari
2. Toca el botón compartir (□↑)
3. Toca **"Agregar a pantalla de inicio"**
4. ¡Listo!

---

## PASO 4: DOMINIO PERSONALIZADO (opcional)

Si quieres una URL como `seconddoe.com`:
1. Compra un dominio en **namecheap.com** (~$10/año)
2. En Vercel → tu proyecto → "Settings" → "Domains"
3. Agrega tu dominio y sigue las instrucciones

---

## RESUMEN DE COSTOS

| Servicio | Costo |
|----------|-------|
| GitHub | GRATIS |
| Vercel hosting | GRATIS |
| PWA (app móvil) | GRATIS |
| Anthropic API | $5 gratis + ~$0.001 por mensaje |
| Dominio .com (opcional) | ~$10/año |

---

## ESTRUCTURA DE ARCHIVOS

```
seconddoe/
├── vercel.json          ← configuración de Vercel
├── api/
│   └── chat.js          ← backend que guarda la API key
└── public/
    ├── index.html       ← la app completa
    ├── manifest.json    ← configuración PWA
    ├── sw.js            ← service worker
    ├── icon-192.png     ← ícono app
    └── icon-512.png     ← ícono app grande
```

---

## ¿NECESITAS AYUDA?

Pídele a Claude que te ayude con cualquier paso.
Solo dile: "estoy en el paso X y me sale este error: ..."
